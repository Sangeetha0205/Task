var appInsights = require('applicationinsights');
var express = require('express');
var createError = require('http-errors');
var process = require('process');

let logger = require('./utils/logging');
let util = require('./utils/utils');

var pingRouter = require('./routes/ping');

var app = express();
var txnId = util.generateTxnID();
var cfgmgr;
const mongoose = require("mongoose");

var kafaklistener = require("./routes/kafka-consumer");

if (process.argv.length > 4) {
  cfgmgr = require('./utils/ConfigManager');
  invokeApp(cfgmgr);
} else {
  cfgmgr = require('./utils/CloudConfigManager');
  var eventEmitter = cfgmgr.eventEmitter;
  cfgmgr.getConfigData().then((data) => {
    invokeApp(data);
  }).catch((err) => {
    logger.logError(null, null, txnId, 1, "END", "NA", "NA", "", null, "SVC-ERR-001", "Service error", err);
    util.exitApp()
  });
}

if (eventEmitter) {
  eventEmitter.on('refreshedConfig', function (data) {
    setAppLocals(data);
  });
}

function setAppLocals(configManagerObj) {
  app.locals.version = configManagerObj.log.revision;
  app.locals.serviceName = configManagerObj.log.microservice;
}

function invokeApp(configManagerObj) {
  const port = configManagerObj.server.port;
  const appinsightsConfig = configManagerObj.appinsights;
  if (appinsightsConfig.appinsightsneeded === 'Y') {
    appInsights
      .setup(appinsightsConfig.key)
      .setSendLiveMetrics(true)
      .setDistributedTracingMode(appInsights.DistributedTracingModes.AI_AND_W3C)
      .start();
  }

  app.use(express.json());
  app.use(express.urlencoded({ extended: false }));
  setAppLocals(configManagerObj);
  app.use('/api/v1/walgreens/nodejs/boilerplate/ping', pingRouter);

  // catch 404 and forward to error handler
  app.use(function (req, res, next) {
    next(createError(404));
  });


  app.listen(port, function () {
    logger.logInfo(null, null, txnId, 3, "START", "NA", "NA", `Ping service running on port:${port}`, null, "SVC-LOG-001", "Service log");
  });


  /**Initializing kafka topic listner */
  kafaklistener.consumeMessage(configManagerObj.kafka.topic);

  /** Intitializing MongoDB connection */
  // eslint-disable-next-line no-undef
  mongoose.Promise = global.Promise;

  const MongooseOptions = {
    server: {
      socketOptions: {
        socketTimeoutMS: 0,
        keepAlive: true,
      },
      reconnectTries: 30,
    },
    replset: {
      socketOptions: {
        socketTimeoutMS: 0,
        keepAlive: true,
      },
      reconnectTries: 30,
    },
    useNewUrlParser: true,
  };

  mongoose.connect(configManagerObj.db.url, MongooseOptions);

}

module.exports = app;

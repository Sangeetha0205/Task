var mongoose = require("mongoose");

// Get the Schema constructor
var Schema = mongoose.Schema;

var PatientSchema = new Schema({

        patientId: {
            "type": "string"
        },
        firstName: {
            "type": "string"
        },
        middleInit: {
            "type": "string"
        },
        lastName: {
            "type": "string"
        },
        surnameSuffix: {
            "type": "string"
        },
        gender: {
            "type": "string"
        },
        email: {
            "type": "string"
        },
        dob: {
            "type": "string"
        },
        phoneNumberAreaCode: {
            "type": "string"
        },
        phoneNumber: {
            "type": "string"
        },
        preferredStoreNumber: {
            "type": "Number"
        },
        lastFilledStoreNumber: {
            "type": "string"
        },
        preferredPaymentMethod: {
            "type": "string"
        },
        previousFilledLastMile: {
            "type": "string"
        },
        addressLine1: {
            "type": "string"
        },
        city: {
            "type": "string"
        },
        zipCode: {
            "type": "string"
        },
        state: {
            "type": "string"
        },
        cardType: {
            "type": "string"
        },
        creditCard: {
            "type": "string"
        },
        lastFourDigits: {
            "type": "Number"
        },
        expiryMonth: {
            "type": "Number"
        },
        expiryYear: {
            "type": "Number"
        },
        isDefault: {
            "type": "boolean"
        }
    
}
,
  { collection: "tbf0_patient" }
);

var Patient = mongoose.model("Patient", PatientSchema);

module.exports = Patient;

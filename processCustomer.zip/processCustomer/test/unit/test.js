/* eslint-disable no-console */
/* eslint-disable no-undef */
let chai = require('chai');
let chaiHttp = require('chai-http');
// eslint-disable-next-line no-unused-vars
let server = require('../../app');
// eslint-disable-next-line no-unused-vars
let should = chai.should();

const expect = chai.expect;

chai.use(chaiHttp);
const url = 'http://localhost:8081';
let logging = require('../../utils/logging');

const kafka = require('./kafka-interface');
var Patient = require("../../model/Patient");
var kafaklistener = require("../../routes/kafka-consumer");

describe('/GET ping service', () => {
	it('it should GET ping status message', (done) => {
		chai.request(url)
			.get('/api/v1/walgreens/nodejs/boilerplate/ping')
			.end((err, res) => {
				res.should.have.status(200);
				res.body.status.should.equal('ok');
				res.body.apiname.should.equal('processcustomer');
				res.body.apiversion.should.equal('v1_0_0');
				done();
			});
	});

});

describe('Test Info/Debug/Error Message Logging', () => {
	it('it should log info message', (done) => {
		logging.logInfo("SampleAplicationName", 101, 1001, 1, "GET", "200", "Success", "TestInfoLog", "100ms", null, null);
		done();
	});
	it('it should log info message', (done) => {
		logging.logInfo(null, 102, 1002, 1, "GET", "200", "Success", "TestInfoLog", "100ms", null, null);
		done();
	});
	it('it should log Debug message', (done) => {
		logging.logDebug("SampleAplicationName", 103, 1003, 2, "GET", "200", "Success", "TestDebugLog", "150ms", null, null);
		done();
	});
	it('it should log Debug message', (done) => {
		logging.logDebug(null, 104, 1004, 2, "GET", "200", "Success", "TestDebugLog", "150ms", null, null);
		done();
	});
	it('it should log error message', (done) => {
		let error = new Error("Internal Error")
		logging.logError("SampleAplicationName", 105, 1005, 3, "GET", "500", "Failure", "Error Occured %s", "50ms", "KFK-ERR-001", "Error accessing input topic", error);
		done();
	});
	it('it should log error message', (done) => {
		let error = new Error("Internal Error")
		logging.logError(null, 106, 1006, 3, "GET", "500", "Failure", "Error Occured %s", "50ms", "KFK-ERR-001", "Error accessing input topic", error);
		done();
	});
});

describe("Test read&update customer data", () => {

	/** Insert test record inside DB */
	before(function (done) {

		/**Test Obj Creation */
		var patientTestDoc = {

			patientId: "TXTX001",
			firstName: "NAME001-BEFORE",
			addressLine1: "ADRESLINE1",
			city: "CITY001",
			zipCode: "ZIP001",
			state: "STATE001",
			cardType: "CARDTYPE001",
			creditCard: "CRD001",
			lastFourDigits: "0000",
			expiryMonth: "12",
			expiryYear: "1111",
			isDefault: true
		};
		Patient.create(patientTestDoc).then(() => done());

	});

	/** Remove the test data after test case execution */
	after(function (done) {
		Patient.deleteOne({ patientId: 'TXTX001' }).then(() => done());
	});

	it('it should read and update', (done) => {

		kafaklistener.consumeMessage("dev-customer");

		kafka.pushdata("dev-customer", "TXTX001", {
			"patientId": "TXTX001",
			"firstName": "NAME001-AFTER",
			"middleInit": "MI",
			"lastName": "nŮźDåŷ:ė",
			"surnameSuffix": "JR",
			"gender": "male",
			"email": "nŮźDåŷ:ė",
			"dob": "08/25/1909",
			"phoneNumberAreaCode": "nŮźDåŷ:ė",
			"phoneNumber": "nŮźDåŷ:ė",
			"preferredStoreNumber": 0,
			"lastFilledStoreNumber": "11231",
			"preferredPaymentMethod": "CR Card",
			"previousFilledLastMile": "ASCX",
			"customerShippingAddress": {
				"addressLine1": "nŮźDåŷ:ė",
				"city": "nŮźDåŷ:ė",
				"zipCode": "XTTA::!Q!~#",
				"state": "string"

			},
			"profilePaymentDetails": [
				{
					"cardType": "Credit",
					"creditCard": "A4745588XXX0037549",
					"lastFourDigits": 77848,
					"expiryMonth": 21,
					"expiryYear": 2025,
					"zipCode": "AZS005",
					"isDefault": true
				}
			]

		});

		const wait = ms => new Promise(resolve => setTimeout(resolve, ms));

		wait(2 * 1000).then(() =>

			Patient.find({ patientId: 'TXTX001' }).then(results => {

				done();
				return expect(results[0].toObject()["firstName"]).equal('NAME001-AFTER');

			}).catch((error) => {
				console.log("Promise rejected", error)
			})

		);
	});
});

const Kafka = require('kafka-node');

const { KeyedMessage } = Kafka;
var kafkahost_url = "localhost:9092";

var kafkaBridge = {

    /**For pushing data to required kafka topic*/
    "pushdata": function (kafkatopic, messagekey, messagevalue) {

        const client = new Kafka.KafkaClient({ kafkaHost: kafkahost_url });
        const Producer = Kafka.Producer;
        const producer = new Producer(client);

        let payloads = [
            {
                topic: kafkatopic,
                messages: new KeyedMessage(messagekey, JSON.stringify(messagevalue))
            }
        ];

        producer.on('ready', function () {
            producer.send(payloads, (err) => {
               console.log(err);
            });
        });
    }
}

module.exports = kafkaBridge;

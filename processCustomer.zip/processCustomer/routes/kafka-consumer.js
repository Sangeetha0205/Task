const kafka = require('kafka-node');
const customerService = require("./customer-service");
const kafka_host = "localhost:9092";

let logger = require('../utils/logging');

var kafkaInterface = {

    /**Kafka listener */
    "consumeMessage": function (kafka_topic) {

        try {

            const client = new kafka.KafkaClient({ kafkaHost: kafka_host });

            let consumer = new kafka.Consumer(
                client,
                [{ topic: kafka_topic, partition: 0 }],
                {
                    autoCommit: true,
                    fetchMaxWaitMs: 1000,
                    fetchMaxBytes: 1024 * 1024,
                    encoding: 'utf8',
                    fromOffset: false,
                    groupId: "customer_group"
                }
            );

            consumer.on('message', function (message) {

                logger.logInfo("Receiving new message from kafka topic..", message.value);
                customerService.updateCutomerData(message);
            })

            consumer.on('error', function (err) {
                logger.logInfo("Kafka connection error..unable to listen kafka ..... poor connection...",err);
            });

        }
        catch (e) {
            logger.logInfo("Unexpected exception caught while reading data from topic...", e);
        }
    }

}

module.exports = kafkaInterface;

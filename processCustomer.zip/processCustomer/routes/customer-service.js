
let logger = require('../utils/logging');
var patientModel = require("../model/Patient");

module.exports = {

    /**For updating PatientObj in mongoDb */
    updateCutomerData: function (message) {

        logger.logInfo("Start processing recevied Object at consumer : updateCustomerData call...");

        try {

            var modelObj = buildModelObject(JSON.parse(message.value));
            var query = { 'patientId': modelObj.patientId };//FindBy patientId

            /**update db operation */
            patientModel.updateOne(query, modelObj, { upsert: false }, function (err, doc) {

                if (err) {
                    logger.logError("Updating data at MongDB failed...", err);
                }
                else {
                    logger.logInfo("Data successfully updated...",doc);
                }

            });
        }
        catch (e) {
            logger.logInfo("Unexpected exception occurs while processing recevied object at consumer...",e);
        }
    }
}

/**For building 'Patientmodel' from kafka topic message */
function buildModelObject(result) {

    // eslint-disable-next-line no-undef
    var responseData = new Object();
    var modelObjectKeys = Object.keys(patientModel.schema.obj);
    var patientKeys = Object.keys(result);
    var shippingAddressKeys = Object.keys(result["customerShippingAddress"]);
    var paymentKeys = Object.keys(result["profilePaymentDetails"][0]);

    logger.logInfo("Start building Patient Model..");

    for (var key in modelObjectKeys) { // Iterating through mongodb model Obj properties

        if (patientKeys.includes(modelObjectKeys[key])) {
            responseData[modelObjectKeys[key]] = result[modelObjectKeys[key]];
        }
        else if (shippingAddressKeys.includes(modelObjectKeys[key])) {
            responseData[modelObjectKeys[key]] = result["customerShippingAddress"][modelObjectKeys[key]];
        }
        else if (paymentKeys.includes(modelObjectKeys[key])) {
            responseData[modelObjectKeys[key]] = result["profilePaymentDetails"][0][modelObjectKeys[key]];
        }

    }

    logger.logInfo("Patient Model for update operation successfully build...");
    return responseData;
}